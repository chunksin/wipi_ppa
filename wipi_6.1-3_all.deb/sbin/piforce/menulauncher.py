#!/usr/bin/env python3 -u
from evdev import *
from time import time
from time import sleep
from select import select
import os, subprocess, sys, logging

logging.basicConfig(filename="/var/log/menulauncher.log", format='%(asctime)s %(message)s', filemode='w')
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)
sys.stderr.write = logger.error
sys.stdout.write = logger.info

activedimm = sys.argv[1]
mode = sys.argv[2]

print("menulauncher script started")
print("active dimm is", activedimm)
print("mode is", mode)

def detect_key_hold(hold_time_sec, activedimm):
    dev = InputDevice('/dev/input/event0')
    state = {}
    buttonarray = []
    Running = True
    while Running:
        r, _, _ = select([dev], [], [], 0.1)
        if (len(buttonarray) == 3 and 315 in buttonarray):
            print('Launch the menu...')
            cp = subprocess.Popen(['python3', '/sbin/piforce/dm_netboot/netdimm_menu', activedimm, '/boot/roms', '--verbose'], preexec_fn=os.setsid)
            buttonarray.clear()
            state.clear()
            sleep(10)
            #dev.close()
            #Running = False
        if r:
            for event in dev.read():
                if event.type == ecodes.EV_KEY:
                    # When the button is pressed, record the time
                    if event.value == 1:
                        state[event.code] = event.timestamp(), event
                    # When released, remove it from the state map and the array if it was previously held
                    if event.value == 0 and event.code in state:
                        del state[event.code]
                        if event.code in buttonarray:
                            buttonarray.remove(event.code)

        now = time()
        for code, ts_event in list(state.items()):
            ts, event = ts_event
            # Check hold time and add to array if greater
            if (now - ts) >= hold_time_sec:
                if not (code in buttonarray):
                    buttonarray.append(code)
                    yield event
                    print(buttonarray)
        continue

if (mode == 'openjvs'):
    print("Starting netdimm_menu script in OpenJVS mode")
    cp = subprocess.Popen(['python3', '/sbin/piforce/dm_netboot/netdimm_menu', activedimm, '/boot/roms', '--verbose'], preexec_fn=os.setsid)
    for event in detect_key_hold(3, activedimm):
        print('a button is being held')
else:
    print('Launch the menu...')
    print("Starting netdimm_menu script in default mode")
    cp = subprocess.Popen(['python3', '/sbin/piforce/dm_netboot/netdimm_menu', activedimm, '/boot/roms', '--verbose'], preexec_fn=os.setsid)
