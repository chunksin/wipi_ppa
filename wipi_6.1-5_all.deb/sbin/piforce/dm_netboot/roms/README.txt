Place netboot roms here if you do not want to configure your own list of directories.
