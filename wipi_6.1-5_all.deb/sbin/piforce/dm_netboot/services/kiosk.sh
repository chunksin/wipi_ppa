#! /bin/bash

/home/pi/netboot/netdimm_ensure 192.168.1.2 /boot/autorun.bin
