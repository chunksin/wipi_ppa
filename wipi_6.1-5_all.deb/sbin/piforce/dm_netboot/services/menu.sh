#! /bin/bash

/home/pi/netboot/netdimm_menu 192.168.1.2 /boot/roms/ --menu-settings-file /boot/netdimm_menu_settings.yaml --persistent
