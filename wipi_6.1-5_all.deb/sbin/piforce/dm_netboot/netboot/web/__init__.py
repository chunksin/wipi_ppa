from netboot.web.app import spawn_app

__all__ = [
    "spawn_app",
]
