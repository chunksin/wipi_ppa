<?php

include 'menu.php';
echo '<html lang="en"><head><meta charset="utf-8"><title>WiPi Netbooter</title>';
echo '<link rel="stylesheet" href="css/sidebarstyles.css">';
echo '<section><center><p>';

?>

<h1><a href=setup.php>Manage WiPi</a></h1>
<br><br><a href="logdownload.php" style="font-weight:normal" class="dropbtn">Download Logs</a><br>
<br><br><a href="update.php" style="font-weight:normal" class="dropbtn">WiPi Updater</a><br>
<br><br><a href="setup.php">Return to Setup Menu</a>