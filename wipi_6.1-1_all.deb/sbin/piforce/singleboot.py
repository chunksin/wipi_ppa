import os, collections, signal, sys, subprocess, socket, csv
from time import sleep

def ping(host):
    command = ['fping', '-c', '1', host]
    return subprocess.call(command) == 0

complete = False
todocount = 0

relayfile = open('/sbin/piforce/relaymode.txt')
relaymode = relayfile.readline()
relayfile.close
zerofile = open('/sbin/piforce/zeromode.txt')
zeromode = zerofile.readline()
zerofile.close

with open('/var/www/html/csv/dimms.csv', newline='') as csvfile:
    dimmreader = csv.DictReader(csvfile)
    rowslist = list(dimmreader)

for row in rowslist:
    row.update({'online':'no'})

while (complete == False):
    todocount = 0
    for row in rowslist:
        if (row['online'] == 'no' and row['defaultgame'] != 'none'):
            todocount = todocount + 1
        print(row['ipaddress'])
        if (row['online'] == 'no'):
            if (ping(row['ipaddress'])):
                row.update({'online':'yes'})
                print(row)
                if (row['defaultgame'] == 'menu'):
                    cmd = 'sudo python3 /sbin/piforce/dm_netboot/netdimm_menu '+row['ipaddress']+' /boot/roms &'
                    os.system(cmd)
                elif (row['defaultgame'] != 'none'):
                    cmd = 'sudo python3 /sbin/piforce/wipiloader.py '+row['defaultgame']+' '+row['ipaddress']+' '+relaymode+' '+zeromode+' '+row['openjvs']+' '+row['openffb']+' &'
                    os.system(cmd)
    if (todocount == 0):
        break